cmd = input(">> ")
if cmd == "host()":
    import host
if cmd == "join()":
    import client